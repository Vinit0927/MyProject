from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

#Creating model table for our CRUD database
class Data(db.Model):
    __tablename__ = "services"
    id = db.Column(db.Integer, primary_key = True)
    service_name = db.Column(db.String(100))
    url = db.Column(db.String(100))
    port_number = db.Column(db.String(100))
    status = db.Column(db.String(100))
    created_date = db.Column(db.String(100))
    updated_date = db.Column(db.String(100))

    def __init__(self, service_name, url, port_number, status, created_date, updated_date):

        self.service_name = service_name
        self.url = url
        self.port_number = port_number
        self.status = status
        self.created_date = created_date
        self.updated_date = updated_date

#Creating model stages table for our CRUD database
class Stages(db.Model):
    __tablename__ = "stages"
    id = db.Column(db.Integer, primary_key = True)
    service_name = db.Column(db.String(100))
    created_date = db.Column(db.String(100))
    updated_date = db.Column(db.String(100))

    def __init__(self, service_name, created_date, updated_date):

        self.service_name = service_name
        self.created_date = created_date
        self.updated_date = updated_date


#Creating model smp_config table for our CRUD database
class SmpConfig(db.Model):
    __tablename__ = "smp_config"
    id = db.Column(db.Integer, primary_key=True)
    tar_filename = db.Column(db.String(100))
    stage = db.Column(db.String(100))
    created_date = db.Column(db.String(100))
    updated_date = db.Column(db.String(100))

    def __init__(self, tar_filename, stage, created_date, updated_date):

        self.tar_filename = tar_filename
        self.stage = stage
        self.created_date = created_date
        self.updated_date = updated_date



#Creating model postal_config table for our CRUD database
class PostalConfig(db.Model):
    __tablename__ = "postal_config"
    id = db.Column(db.Integer, primary_key=True)
    tar_filename = db.Column(db.String(100))
    stage = db.Column(db.String(100))
    created_date = db.Column(db.String(100))
    updated_date = db.Column(db.String(100))

    def __init__(self, tar_filename, stage, created_date, updated_date):

        self.tar_filename = tar_filename
        self.stage = stage
        self.created_date = created_date
        self.updated_date = updated_date