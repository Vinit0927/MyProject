from flask import Blueprint
from urllib.request import urlretrieve
import tarfile
import requests
import os
import time
start = time.time()
awsutilities = Blueprint('awsutilities',__name__)

@awsutilities.route('/', methods=['GET', 'POST'])
def home():
    return 'welcome to aws utlities services'


@awsutilities.route('/insert', methods=['GET', 'POST'])
def home1():
    return 'welcome to insert aws utlities'

