from tkinter.filedialog import SaveAs
from flask import Blueprint
from flask_wtf import FlaskForm
from flask import Flask, render_template, request, redirect, flash, url_for
from .models import db, Data, Stages, SmpConfig, PostalConfig
app = Flask(__name__)
main = Blueprint("main", __name__)

from app import create_app

app = create_app()
#This is the index route where we are going to
#query on all our data
@app.route('/')
def Index():
    all_data = Data.query.all()
    return render_template("index.html", employees = all_data)

#this route is for inserting data to sqlite database via html forms
@app.route('/insert', methods = ['POST'])
def insert():

    if request.method == 'POST':

        service_name = request.form['service_name']
        url = request.form['url']
        port_number = request.form['port_number']
        status = request.form['status']
        created_date = request.form['created_date']
        updated_date = request.form['updated_date']

        my_data = Data(service_name, url, port_number, status, created_date, updated_date)
        db.session.add(my_data)
        db.session.commit()

        flash("Data Inserted Successfully")

        return redirect(url_for('Index'))


#this is our update route where we are going to update our servicedata
@app.route('/update', methods = ['GET', 'POST'])
def update():

    if request.method == 'POST':
        my_data = Data.query.get(request.form.get('id'))
        my_data.service_name = request.form['service_name']
        my_data.url = request.form['url']
        my_data.port_number = request.form['port_number']
        my_data.status = request.form['status']
        my_data.created_date = request.form['created_date']
        my_data.updated_date = request.form['updated_date']

        db.session.commit()
        flash("Record Updated Successfully")
        return redirect(url_for('Index'))

#This route is for deleting our servicedata
@app.route('/delete/<id>/', methods = ['GET', 'POST'])
def delete(id):
    my_data = Data.query.get(id)
    db.session.delete(my_data)
    db.session.commit()
    flash("Record Deleted Successfully")

    return redirect(url_for('Index'))




#This is the index route where we are going to Stages
#query on all our stages data
@app.route('/stages')
def Index_Stages():
        all_data = Stages.query.all()
        return render_template("index_stages.html", employees = all_data)

#this route is for inserting data to sqlite database via html forms
@app.route('/insert_stages', methods = ['POST'])
def insert_stages():

    if request.method == 'POST':

        service_name = request.form['service_name']
        created_date = request.form['created_date']
        updated_date = request.form['updated_date']

        my_data = Stages(service_name, created_date, updated_date)
        db.session.add(my_data)
        db.session.commit()

        flash("Data Inserted Successfully")

        return redirect(url_for('Index_Stages'))


#this is our update route where we are going to update our stagesdata
@app.route('/update_stages', methods = ['GET', 'POST'])
def update_stages():

    if request.method == 'POST':
        my_data = Stages.query.get(request.form.get('id'))
        my_data.service_name = request.form['service_name']
        my_data.created_date = request.form['created_date']
        my_data.updated_date = request.form['updated_date']

        db.session.commit()
        flash("Record Updated Successfully")
        return redirect(url_for('Index_Stages'))

#This route is for deleting our stagesdata
@app.route('/delete_stages/<id>/', methods = ['GET', 'POST'])
def delete_stages(id):
    my_data = Stages.query.get(id)
    db.session.delete(my_data)
    db.session.commit()
    flash("Record Deleted Successfully")

    return redirect(url_for('Index_Stages'))




#This is the index route where we are going to Smp_config
#query on all our smp_config data
@app.route('/smp')
def Index_Smp():
        all_data = SmpConfig.query.all()
        return render_template("index_smp.html", employees = all_data)

#this route is for inserting data to sqlite database via html forms
@app.route('/insert_smp', methods = ['POST'])
def insert_smp():

    if request.method == 'POST':

        tar_filename = request.form['tar_filename']
        stage = request.form['stage']
        created_date = request.form['created_date']
        updated_date = request.form['updated_date']

        my_data = SmpConfig(tar_filename, stage, created_date, updated_date)
        db.session.add(my_data)
        db.session.commit()

        flash("Data Inserted Successfully")

        return redirect(url_for('Index_Smp'))


#this is our update route where we are going to update our smpdata
@app.route('/update_smp', methods = ['GET', 'POST'])
def update_smp():

    if request.method == 'POST':
        my_data = SmpConfig.query.get(request.form.get('tar_filename'))
        my_data.stage = request.form['stage']
        my_data.created_date = request.form['created_date']
        my_data.updated_date = request.form['updated_date']

        db.session.commit()
        flash("Record Updated Successfully")
        return redirect(url_for('Index_Smp'))

#This route is for deleting our smpdata
@app.route('/delete_smp/<tar_filename>/', methods = ['GET', 'POST'])
def delete_smp(tar_filename):
    my_data = SmpConfig.query.get(tar_filename)
    db.session.delete(my_data)
    db.session.commit()
    flash("Record Deleted Successfully")

    return redirect(url_for('Index_Smp'))



#This is the index route where we are going to Postal_config
#query on all our postal_config data
@app.route('/postal')
def Index_Postal():
        all_data = PostalConfig.query.all()
        return render_template("index_postal.html", employees = all_data)

#this route is for inserting data to sqlite database via html forms
@app.route('/insert_postal', methods = ['POST'])
def insert_postal():

    if request.method == 'POST':

        tar_filename = request.form['tar_filename']
        stage = request.form['stage']
        created_date = request.form['created_date']
        updated_date = request.form['updated_date']

        my_data = PostalConfig(tar_filename, stage, created_date, updated_date)
        db.session.add(my_data)
        db.session.commit()

        flash("Data Inserted Successfully")

        return redirect(url_for('Index_Postal'))


#this is our update route where we are going to update our postaldata
@app.route('/update_postal', methods = ['GET', 'POST'])
def update_postal():

    if request.method == 'POST':
        my_data = PostalConfig.query.get(request.form.get('tar_filename'))
        my_data.stage = request.form['stage']
        my_data.created_date = request.form['created_date']
        my_data.updated_date = request.form['updated_date']

        db.session.commit()
        flash("Record Updated Successfully")
        return redirect(url_for('Index_Postal'))

#This route is for deleting our postaldata
@app.route('/delete_postal/<tar_filename>/', methods = ['GET', 'POST'])
def delete_postal(tar_filename):
    my_data = PostalConfig.query.get(tar_filename)
    db.session.delete(my_data)
    db.session.commit()
    flash("Record Deleted Successfully")

    return redirect(url_for('Index_Postal'))

app.run(host='0.0.0.0', port=5000)