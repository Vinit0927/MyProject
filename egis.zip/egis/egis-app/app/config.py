
class Configs:

    SQLALCHEMY_DATABASE_URI = 'sqlite:///E:/var/fedex/egis/data_repo/Data_Processing/egis.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = '99bb019100e7b887661428d1d6a08630'
