from flask import Blueprint
from urllib.request import urlretrieve
import tarfile
import requests
import os
import time
start = time.time()
fileops = Blueprint('fileops',__name__)

@fileops.route('/', methods=['GET', 'POST'])
def home():
    return 'hello world fileops'

@fileops.route('/downloadXML', methods = ['POST','GET'])
def xml_download():
    url='https://here.flexnetoperations.com/control/navt/login?username=egis-it-support@corp.ds.fedex.com&password=becarefulnow&action=authenticate&nextURL=%2Fcontrol%2Fnavt%2FfilesDownloadable%3Faction%3Dxml%26limitDays%3D30'
    dst = 'C:/Vinit/FileNotDownload.xml'

    resp = requests.get(url)
    with open(dst, 'wb') as foutput:
        foutput.write(resp.content)
        print("Done")
        return "FND XML File downloaded"

@fileops.route('/download', methods = ['GET'])
def download_file():
         url = 'https://download.flexnetoperations.com/439214/navt/547/18806547/VMAM211F0WVM000DSMP0.tar?ftpRequestID=9364873947&server=download.flexnetoperations.com&dtm=DTM20220327025847NjEwMjAxODA3&authparam=1648375127_8adca9b61844d0ae76cb6dadf7f85559&ext=.tar'
         dst = 'C:/Vinit/VMAM211F0WVM000DSMP0.tar'

         urlretrieve(url, dst)
         print("Request sent to server")
         return "File downloaded in :" + dst

@fileops.route('/tarextract', methods = ['POST'])
def un_zipFiles():

        src='C:/Vinit/Affy_test_data.tar.gz'
        dst='C:/Vinit/Ex'
        my_tar = tarfile.open(src)
        my_tar.extractall(dst)
        my_tar.close()
        return "Extracted"

@fileops.route('/tarcompress', methods = ['GET'])
def compressed():
        os.system("tar -cvf C:/Vinit/home.tar.gz C:/Vinit/Sam")
        os.system("gzip C:/Vinit/home.tar.gz")
        end = time.time()
        print("Elapsed time: %s"%(end - start,))
        return "Compressed"