import requests
from urllib.request import urlretrieve
from flask import Flask
app = Flask(__name__)

@app.route('/')
def xml_download():
    resp = requests.get('https://here.flexnetoperations.com/control/navt/login?username=egis-it-support@corp.ds.fedex.com&password=becarefulnow&action=authenticate&nextURL=%2Fcontrol%2Fnavt%2FfilesDownloadable%3Faction%3Dxml%26limitDays%3D30')
    with open('C:/Vinit/FileNotDownload.xml', 'wb') as foutput:
        foutput.write(resp.content)
        print("Done")
        return "FND XML File downloaded"


if __name__ == "__main__":
   app.run(host='0.0.0.0', port = 8000)



#url = 'https://here.flexnetoperations.com/control/navt/login?username=egis-it-support@corp.ds.fedex.com&password=becarefulnow&action=authenticate&nextURL=%2Fcontrol%2Fnavt%2FfilesDownloadable%3Faction%3Dxml%26limitDays%3D30'
    #dst = 'C:/Vinit/FilesNotDownloaded.xml'
    #urlretrieve(url, dst)