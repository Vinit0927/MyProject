import tarfile
from flask import  Flask

app = Flask(__name__)

@app.route('/')
def un_zipFiles():
    my_tar = tarfile.open('C:/Vinit/Affy_test_data.tar.gz')
    my_tar.extractall('C:/Vinit/Ex')
    my_tar.close()
    return "Extracted"

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000)