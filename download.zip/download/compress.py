import tarfile
import os
import time
start = time.time()
from flask import  Flask
app = Flask(__name__)

@app.route('/')
def compressed():
    os.system("tar -cvf C:/Vinit/home.tar.gz C:/Vinit/Sam")
    os.system("gzip C:/Vinit/home.tar.gz")

    end = time.time()
    print("Elapsed time: %s"%(end - start,))
    return "Compressed"

if __name__ == "__main__":
    app.run(host='0.0.0.0', port=8000)



#file_name = "C:/Vinit/home.tar.gz"
#@app.route('/')
#def compressed():
    #tar = tarfile.open(file_name, "w:gz")
    #os.chdir("C:/Vinit/Sam")
    #for name in os.listdir("."):
        #tar.add(name)
        #tar.close()
        #return "Compressed"