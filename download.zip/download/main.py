from urllib.request import urlretrieve
from flask import Flask
app = Flask(__name__)

@app.route('/')
def hello_world():
     url = 'https://download.flexnetoperations.com/439214/navt/547/18806547/VMAM211F0WVM000DSMP0.tar?ftpRequestID=9364873947&server=download.flexnetoperations.com&dtm=DTM20220327025847NjEwMjAxODA3&authparam=1648375127_8adca9b61844d0ae76cb6dadf7f85559&ext=.tar'
     dst = 'C:/Vinit/VMAM211F0WVM000DSMP0.tar'
     urlretrieve(url, dst)
     print("Request sent to server")
     return "File downloaded in :" + dst


if __name__ == "__main__":
   app.run(host='0.0.0.0', port = 8000)

